'use strict';
// Interface do Life: início, loja, biblioteca, jogo, amigos, comunidade,
// downloads, carrinho, publicar e configurações.

const $view = document.getElementById('view');
const $content = document.querySelector('.content');

/* ============================ utilidades ============================ */
const esc = (s) =>
  String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const enc = encodeURIComponent;
const brl = (n) => (n === 0 ? 'Grátis' : n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }));
const hours = (min) => (min >= 60 ? `${Math.floor(min / 60)} h ${min % 60} min` : `${min} min`);

async function api(url, opts = {}) {
  const init = { method: opts.method || 'GET', headers: { 'Content-Type': 'application/json' } };
  if (opts.body !== undefined) init.body = JSON.stringify(opts.body);
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Erro inesperado.');
  return data;
}

const ICONS = {
  home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  bag: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
  grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
  bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
  cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
  left: '<polyline points="15 18 9 12 15 6"/>',
  right: '<polyline points="9 18 15 12 9 6"/>',
  play: '<polygon points="5 3 19 12 5 21 5 3"/>',
  back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',
};
const icon = (name, size = 20) =>
  `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;

/* ============================== estado ============================== */
const S = {
  q: '', genre: '', sort: 'rating', libTab: 'all',
  cart: [], favorites: new Set(), liked: new Set(),
  profile: { name: 'Jogador', reduceMotion: false },
  notes: [], unread: 0, history: [],
};
try { S.cart = JSON.parse(localStorage.getItem('life-cart') || '[]'); } catch (e) { S.cart = []; }
if (!Array.isArray(S.cart)) S.cart = [];

const gamesById = new Map();
async function getGames(query = '') {
  const list = await api('/api/games' + query);
  list.forEach((g) => gamesById.set(g.id, g));
  return list;
}

const downloads = new Map(); // id -> { pct, title, size, speed, dur }
let timers = [];
const every = (fn, ms) => { const t = setInterval(fn, ms); timers.push(t); return t; };
const clearTimers = () => { timers.forEach(clearInterval); timers = []; };

let renderId = 0;
let current = { name: '', arg: '' };
const setView = (rid, html) => {
  if (rid !== renderId) return false;
  $view.innerHTML = html;
  return true;
};

function saveCart() {
  try { localStorage.setItem('life-cart', JSON.stringify(S.cart)); } catch (e) { /* sem armazenamento */ }
  updateBadge();
}
function updateBadge() {
  const b = document.getElementById('cart-badge');
  b.textContent = S.cart.length;
  b.hidden = S.cart.length === 0;
}

let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

function notify(text) {
  S.notes.unshift({ text, time: new Date() });
  S.notes = S.notes.slice(0, 8);
  S.unread++;
  document.getElementById('bell-dot').hidden = false;
  if (!document.getElementById('notes').hidden) paintNotes();
}
function paintNotes() {
  const el = document.getElementById('notes');
  const fmt = (d) => d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  el.innerHTML = '<h4>Notificações</h4>' + (S.notes.length
    ? S.notes.map((n) => `<div class="note">${esc(n.text)}<small>${fmt(n.time)}</small></div>`).join('')
    : '<div class="none">Nada por aqui ainda.</div>');
}

/* ========================= pedaços de interface ========================= */
function art(g, cls = '') {
  return `<div class="art ${cls}" style="--c1:${esc(g.colors[0])};--c2:${esc(g.colors[1])}"><span class="art-emoji">${esc(g.emoji)}</span><span class="art-title">${esc(g.title)}</span></div>`;
}

function priceHTML(g) {
  if (g.price === 0) return '<span class="price">Grátis</span>';
  return `${g.discount ? `<span class="disc-badge">-${g.discount}%</span><span class="old">${brl(g.originalPrice)}</span>` : ''}<span class="price">${brl(g.price)}</span>`;
}

function card(g, i = 0) {
  return `<article class="card reveal" style="--i:${i}" data-action="open" data-id="${esc(g.id)}">
    <div class="card-art">${art(g)}${g.discount ? `<span class="disc">-${g.discount}%</span>` : ''}</div>
    <div class="card-body">
      <div class="card-title">${esc(g.title)}</div>
      <div class="card-sub">${esc(g.genres[0] || '')}</div>
      <div class="card-price">${priceHTML(g)}</div>
    </div>
  </article>`;
}

function avatar(name, status, cls = '') {
  const h = Math.abs([...String(name)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 7)) % 360;
  return `<span class="avatar ${cls}" style="--h:${h}">${esc(String(name).charAt(0).toUpperCase())}${status ? `<i class="dot ${esc(status)}"></i>` : ''}</span>`;
}

function statusText(f) {
  const g = f.game && gamesById.get(f.game);
  if (f.status === 'ingame') return `Jogando ${g ? g.title : 'um jogo'}`;
  if (f.status === 'menu') return `No menu principal${g ? ' · ' + g.title : ''}`;
  if (f.status === 'online') return 'Online';
  if (f.status === 'away') return 'Ausente';
  return `Offline ${f.lastSeen || ''}`.trim();
}

function friendRow(f, i) {
  const g = f.game && gamesById.get(f.game);
  const text = esc(statusText(f));
  const stat = g
    ? `<a class="fstat" href="#/game/${enc(g.id)}">${text}</a>`
    : `<span class="fstat">${text}</span>`;
  return `<div class="friend reveal" style="--i:${i}">${avatar(f.name, f.status, 'lg')}<div><div class="fname">${esc(f.name)}</div>${stat}</div></div>`;
}

function countUp(el, to, fmt = (n) => String(Math.round(n)), dur = 900) {
  if (S.profile.reduceMotion) { el.textContent = fmt(to); return; }
  const t0 = performance.now();
  const step = (t) => {
    const k = Math.min(1, (t - t0) / dur);
    el.textContent = fmt(to * (1 - Math.pow(1 - k, 3)));
    if (k < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function placeTabIndicator() {
  const tabs = document.querySelector('.tabs');
  if (!tabs) return;
  const on = tabs.querySelector('.tab.on');
  const ind = tabs.querySelector('.tab-ind');
  if (!on || !ind) return;
  ind.style.width = on.offsetWidth + 'px';
  ind.style.transform = `translateX(${on.offsetLeft}px)`;
}

/* ============================== navegação ============================== */
const NAV = [
  ['', 'home', 'Início'],
  ['store', 'bag', 'Loja'],
  ['library', 'grid', 'Biblioteca'],
  ['friends', 'users', 'Amigos'],
  ['community', 'chat', 'Comunidade'],
  ['downloads', 'download', 'Downloads'],
  ['publish', 'plus', 'Publicar jogo'],
];

function buildChrome() {
  document.getElementById('nav').innerHTML =
    '<span class="nav-ind" id="nav-ind"></span>' +
    NAV.map(([r, ic, label]) => `<a class="nav-link" href="#/${r}" data-nav="${r}">${icon(ic)}<span>${label}</span></a>`).join('') +
    '<span class="nav-spacer"></span><div id="mini-dl"></div>' +
    `<a class="nav-link" href="#/settings" data-nav="settings">${icon('sliders')}<span>Configurações</span></a>`;
  document.getElementById('search-ico').innerHTML = icon('search', 18);
  document.getElementById('bell-ico').innerHTML = icon('bell');
  document.getElementById('cart-ico').innerHTML = icon('cart');
}

function updateNav(name) {
  const key = name === 'game' ? 'store' : name;
  let active = null;
  document.querySelectorAll('.nav-link').forEach((a) => {
    const on = a.dataset.nav === key;
    a.classList.toggle('active', on);
    if (on) active = a;
  });
  const ind = document.getElementById('nav-ind');
  if (active && ind) {
    ind.classList.add('on');
    ind.style.height = active.offsetHeight + 'px';
    ind.style.transform = `translateY(${active.offsetTop}px)`;
  } else if (ind) {
    ind.classList.remove('on');
  }
}

function applyProfile() {
  document.body.classList.toggle('reduce-motion', !!S.profile.reduceMotion);
  document.getElementById('profile-chip').innerHTML =
    `${avatar(S.profile.name, '')}<span class="ptext"><div class="pname">${esc(S.profile.name)}</div><div class="pstat">Online</div></span>`;
}

/* =============================== telas =============================== */
async function homeView() {
  const rid = renderId;
  const [games, lib] = await Promise.all([getGames(), api('/api/library')]);
  const owned = new Set(lib.map((e) => e.id));
  const feat = games.filter((g) => g.featured);
  const heroList = feat.length ? feat : games.slice(0, 4);
  const top = [...games].sort((a, b) => b.rating - a.rating).slice(0, 3);
  const deals = games.filter((g) => g.discount > 0).sort((a, b) => b.discount - a.discount).slice(0, 5);
  const best = [...games].sort((a, b) => b.rating - a.rating).slice(0, 5);
  const wish = games.filter((g) => S.favorites.has(g.id) && !owned.has(g.id)).slice(0, 5);

  const slides = heroList.map((g, i) => {
    const own = owned.has(g.id);
    return `<article class="hero-slide ${i === 0 ? 'on' : ''}" style="--c1:${esc(g.colors[0])};--c2:${esc(g.colors[1])}">
      <div class="hero-bg"></div>
      <span class="hero-emoji">${esc(g.emoji)}</span>
      <div class="hero-copy">
        <span class="pill">Em destaque</span>
        <h2 class="hero-title">${esc(g.title)}</h2>
        <div class="hero-meta">${g.genres.map(esc).join(' · ')} · ${g.rating}% positivas</div>
        <p class="hero-tag">${esc(g.tagline)}</p>
        <div class="hero-price">${priceHTML(g)}</div>
        <div class="hero-actions">
          ${own
            ? `<button class="btn lg" data-action="open" data-id="${esc(g.id)}">Na biblioteca</button>`
            : `<button class="btn lg" data-action="buy-now" data-id="${esc(g.id)}">${g.price === 0 ? 'Obter grátis' : 'Comprar agora'}</button>`}
          <button class="btn ghost lg" data-action="open" data-id="${esc(g.id)}">Ver jogo</button>
          <button class="icon-btn heart ${S.favorites.has(g.id) ? 'on' : ''}" data-action="fav" data-id="${esc(g.id)}" aria-label="Favoritar">${icon('heart')}</button>
        </div>
      </div>
    </article>`;
  }).join('');

  const html = `
    <div class="home-top reveal" style="--i:0">
      <div class="hero" id="hero">
        ${slides}
        <div class="dots" id="dots">${heroList.map((_, i) => `<button class="dot-b ${i === 0 ? 'on' : ''}" data-action="hero" data-to="${i}" aria-label="Destaque ${i + 1}"></button>`).join('')}</div>
        <div class="hero-nav">
          <button class="icon-btn" data-action="hero" data-to="prev" aria-label="Anterior">${icon('left')}</button>
          <button class="icon-btn" data-action="hero" data-to="next" aria-label="Próximo">${icon('right')}</button>
        </div>
      </div>
      <div class="side-list">
        ${top.map((g) => `<div class="side-tile" data-action="open" data-id="${esc(g.id)}">${art(g)}</div>`).join('')}
      </div>
    </div>

    <div class="section-head reveal" style="--i:2"><h2>Ofertas em destaque</h2><a href="#/store">Ver mais →</a></div>
    <div class="grid five">${deals.map((g, i) => card(g, i + 3)).join('')}</div>

    <div class="section-head reveal" style="--i:8"><h2>Mais bem avaliados</h2><a href="#/store">Ver mais →</a></div>
    <div class="grid five">${best.map((g, i) => card(g, i + 9)).join('')}</div>

    ${wish.length ? `<div class="section-head reveal" style="--i:14"><h2>Sua lista de desejos</h2></div>
    <div class="grid five">${wish.map((g, i) => card(g, i + 15)).join('')}</div>` : ''}`;
  if (!setView(rid, html)) return;
  initHero(heroList.length);
}

let heroCtl = null;
function initHero(n) {
  const hero = document.getElementById('hero');
  if (!hero || n === 0) return;
  let idx = 0;
  const slides = [...hero.querySelectorAll('.hero-slide')];
  const dots = [...hero.querySelectorAll('.dot-b')];
  const show = (to) => {
    idx = ((to % n) + n) % n;
    slides.forEach((s, i) => s.classList.toggle('on', i === idx));
    dots.forEach((d, i) => {
      d.classList.remove('on');
      if (i === idx) { void d.offsetWidth; d.classList.add('on'); }
    });
  };
  let timer = every(() => { if (!hero.matches(':hover')) show(idx + 1); }, 7000);
  heroCtl = {
    go(to) {
      show(to === 'next' ? idx + 1 : to === 'prev' ? idx - 1 : Number(to));
      clearInterval(timer);
      timer = every(() => { if (!hero.matches(':hover')) show(idx + 1); }, 7000);
    },
  };
}

async function storeView() {
  const rid = renderId;
  const genres = await api('/api/genres');
  const html = `
    <div class="page-head reveal" style="--i:0"><h1>Loja</h1>
      <label class="muted">Ordenar por
        <select id="sort">
          ${[['rating', 'Melhor avaliados'], ['discount', 'Maiores descontos'], ['new', 'Lançamentos'], ['price-asc', 'Menor preço'], ['price-desc', 'Maior preço'], ['az', 'A-Z']]
            .map(([v, l]) => `<option value="${v}" ${S.sort === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select></label>
    </div>
    <div class="chips reveal" style="--i:1" id="chips">
      <button class="chip ${S.genre === '' ? 'on' : ''}" data-action="genre" data-genre="">Todos</button>
      ${genres.map((x) => `<button class="chip ${S.genre === x ? 'on' : ''}" data-action="genre" data-genre="${esc(x)}">${esc(x)}</button>`).join('')}
    </div>
    <div id="grid" class="grid"></div>`;
  if (!setView(rid, html)) return;
  document.getElementById('sort').addEventListener('change', (e) => { S.sort = e.target.value; loadGrid(); });
  await loadGrid();
}

async function loadGrid() {
  const params = new URLSearchParams({ q: S.q, genre: S.genre, sort: S.sort });
  const games = await getGames('?' + params);
  const grid = document.getElementById('grid');
  if (!grid) return;
  grid.innerHTML = games.length
    ? games.map((g, i) => card(g, Math.min(i, 10))).join('')
    : `<div class="empty" style="grid-column:1/-1"><div class="big">${icon('search', 34)}</div>Nenhum jogo encontrado.</div>`;
  document.querySelectorAll('#chips .chip').forEach((c) => c.classList.toggle('on', c.dataset.genre === S.genre));
}

function paintLibrary(items) {
  const list = document.getElementById('lib-list');
  if (!list) return;
  const shown = items.filter((e) => S.libTab === 'all' || (S.libTab === 'installed' && e.installed) || (S.libTab === 'favorites' && S.favorites.has(e.id)));
  if (!shown.length) {
    list.innerHTML = `<div class="empty"><div class="big">${icon('grid', 34)}</div>${S.libTab === 'all' ? 'Você ainda não tem jogos.' : 'Nada aqui por enquanto.'}<a class="btn sm" href="#/store">Ir para a loja</a></div>`;
    return;
  }
  list.innerHTML = shown.map((e, i) => {
    const g = e.game;
    const dl = downloads.get(g.id);
    let actions;
    if (dl) {
      actions = `<div class="dl-wrap"><span class="bar"><i data-dl-bar="${esc(g.id)}" style="width:${dl.pct}%"></i></span><small><span data-dl-pct="${esc(g.id)}">${Math.round(dl.pct)}%</span><span data-dl-info="${esc(g.id)}"></span></small></div>`;
    } else if (e.installed) {
      actions = `<button class="btn" data-action="play" data-id="${esc(g.id)}">${icon('play', 16)} Jogar</button>`;
    } else {
      actions = `<button class="btn ghost" data-action="install" data-id="${esc(g.id)}">${icon('download', 16)} Instalar</button>`;
    }
    return `<div class="row reveal" style="--i:${Math.min(i, 10)}">
      <div class="thumb">${art(g, 'thumb')}</div>
      <div class="grow"><div class="rtitle" data-action="open" data-id="${esc(g.id)}">${esc(g.title)}</div>
        <div class="muted">${esc(g.sizeGB)} GB · ${e.installed ? 'Instalado' : 'Não instalado'}${e.playMinutes ? ' · ' + hours(e.playMinutes) + ' jogadas' : ''}</div></div>
      <div class="actions">${actions}
        <button class="icon-btn heart ${S.favorites.has(g.id) ? 'on' : ''}" data-action="fav" data-id="${esc(g.id)}" aria-label="Favoritar">${icon('heart')}</button></div>
    </div>`;
  }).join('');
}

let libItems = [];
async function libraryView() {
  const rid = renderId;
  libItems = await api('/api/library');
  libItems.forEach((e) => gamesById.set(e.id, e.game));
  libItems.forEach((e) => { if (e.favorite) S.favorites.add(e.id); });
  const installed = libItems.filter((e) => e.installed).length;
  const minutes = libItems.reduce((s, e) => s + e.playMinutes, 0);
  const favs = libItems.filter((e) => S.favorites.has(e.id)).length;
  const html = `
    <div class="page-head reveal" style="--i:0"><h1>Biblioteca</h1></div>
    <div class="stats reveal" style="--i:1">
      <div class="stat"><b data-count="${libItems.length}">0</b><span>jogos</span></div>
      <div class="stat"><b data-count="${installed}">0</b><span>instalados</span></div>
      <div class="stat"><b data-count="${Math.round(minutes / 6) / 10}" data-dec="1">0</b><span>horas jogadas</span></div>
    </div>
    <div class="tabs reveal" style="--i:2">
      <span class="tab-ind"></span>
      <button class="tab ${S.libTab === 'all' ? 'on' : ''}" data-action="lib-tab" data-tab="all">Todos os jogos</button>
      <button class="tab ${S.libTab === 'installed' ? 'on' : ''}" data-action="lib-tab" data-tab="installed">Instalados (${installed})</button>
      <button class="tab ${S.libTab === 'favorites' ? 'on' : ''}" data-action="lib-tab" data-tab="favorites">Favoritos (${favs})</button>
    </div>
    <div id="lib-list"></div>`;
  if (!setView(rid, html)) return;
  paintLibrary(libItems);
  placeTabIndicator();
  $view.querySelectorAll('[data-count]').forEach((el) => {
    const dec = el.dataset.dec ? Number(el.dataset.dec) : 0;
    countUp(el, Number(el.dataset.count), (n) => n.toFixed(dec).replace('.', ','));
  });
}

async function gameView(id) {
  const rid = renderId;
  const [g, lib, friends] = await Promise.all([
    api('/api/games/' + enc(id)),
    api('/api/library'),
    api('/api/games/' + enc(id) + '/friends'),
  ]);
  gamesById.set(g.id, g);
  const entry = lib.find((e) => e.id === g.id);
  const dl = downloads.get(g.id);
  const inCart = S.cart.includes(g.id);
  const fav = S.favorites.has(g.id);
  const heart = `<button class="icon-btn heart ${fav ? 'on' : ''}" data-action="fav" data-id="${esc(g.id)}" aria-label="Favoritar">${icon('heart')}</button>`;

  let actions;
  if (entry && dl) {
    actions = `<div class="dl-wrap"><span class="bar"><i data-dl-bar="${esc(g.id)}" style="width:${dl.pct}%"></i></span><small><span data-dl-pct="${esc(g.id)}">${Math.round(dl.pct)}%</span><span data-dl-info="${esc(g.id)}"></span></small></div>${heart}`;
  } else if (entry && entry.installed) {
    actions = `<button class="btn lg" data-action="play" data-id="${esc(g.id)}">${icon('play', 18)} Jogar</button>
      <button class="btn ghost" data-action="uninstall" data-id="${esc(g.id)}">${icon('trash', 16)} Desinstalar</button>${heart}`;
  } else if (entry) {
    actions = `<button class="btn lg" data-action="install" data-id="${esc(g.id)}">${icon('download', 18)} Instalar (${esc(g.sizeGB)} GB)</button>${heart}`;
  } else {
    actions = `<span class="buyline" style="margin:0">${priceHTML(g)}</span>
      ${inCart ? '<a class="btn ghost" href="#/cart">No carrinho — ver</a>'
               : `<button class="btn ghost" data-action="add-cart" data-id="${esc(g.id)}">${g.price === 0 ? 'Adicionar' : 'Adicionar ao carrinho'}</button>`}
      <button class="btn lg" data-action="buy-now" data-id="${esc(g.id)}">${g.price === 0 ? 'Obter grátis' : 'Comprar'}</button>${heart}`;
  }

  const achIcons = ['🏆', '⭐', '🔥', '💎', '🎯', '⚡', '👑'];
  const unlocked = entry ? entry.achievementsUnlocked : 0;
  const achPanel = entry ? `
    <div class="panel reveal" style="--i:3">
      <h3>Conquistas <span class="muted">${unlocked}/${g.achievementsTotal}</span></h3>
      <span class="bar"><i style="width:${Math.round((unlocked / g.achievementsTotal) * 100)}%;transition:none"></i></span>
      <div class="badges">${achIcons.map((ic, i) => `<span class="achv ${i < unlocked ? 'on' : ''}" title="Conquista ${i + 1}">${ic}</span>`).join('')}</div>
      <p class="muted" style="margin-top:12px">Tempo de jogo: ${entry.playMinutes ? hours(entry.playMinutes) : 'ainda não jogou'}</p>
    </div>` : `
    <div class="shots reveal" style="--i:3;grid-column:1/-1;margin-top:0">
      ${[0, 1, 2].map((k) => `<div class="shot">${art({ ...g, emoji: ['🌄', g.emoji, '✨'][k], title: '', colors: k === 1 ? g.colors : [g.colors[1], g.colors[0]] }, 'small')}</div>`).join('')}
    </div>`;

  const friendsPanel = `
    <div class="panel reveal" style="--i:4">
      <h3>Amigos que jogam <span class="muted">${friends.length}</span></h3>
      ${friends.length ? friends.map((f) => `<div class="friend-line">${avatar(f.name, f.status)}<div><b>${esc(f.name)}</b><div class="muted" style="font-size:13px">${esc(statusText(f))}</div></div></div>`).join('')
        : '<p class="muted">Nenhum amigo seu joga este jogo ainda.</p>'}
    </div>`;

  const reqRows = (r) => [['Sistema', r.so], ['Processador', r.cpu], ['Memória', r.ram], ['Placa de vídeo', r.gpu], ['Armazenamento', r.disco]]
    .map(([k, v]) => `<div class="req-row"><span>${k}</span><span>${esc(v)}</span></div>`).join('');

  const html = `
    <a class="back reveal" style="--i:0" href="#/store" data-action="back">${icon('back', 18)} Voltar</a>
    <div class="banner reveal" style="--i:1;--c1:${esc(g.colors[0])};--c2:${esc(g.colors[1])}">
      <div class="hero-bg"></div><span class="hero-emoji">${esc(g.emoji)}</span>
    </div>
    <div class="game-head reveal" style="--i:2">
      <div class="cover">${art(g)}</div>
      <div class="ginfo">
        <h1>${esc(g.title)}</h1>
        <div class="muted">${esc(g.developer)} · ${esc(g.releaseDate)} · ${g.rating > 0 ? g.rating + '% positivas' : 'sem avaliações'}</div>
        <div>${g.genres.map((x) => `<span class="tag">${esc(x)}</span>`).join('')}</div>
        <div class="buyline">${actions}</div>
      </div>
    </div>
    <div class="two-col">
      ${achPanel}
      ${friendsPanel}
    </div>
    <div class="panel reveal" style="--i:5;margin-top:18px">
      <h3>Sobre o jogo</h3>
      <p style="line-height:1.6">${esc(g.description)}</p>
    </div>
    <div class="panel reveal" style="--i:6;margin-top:18px">
      <h3>Requisitos de sistema</h3>
      <div class="req-tabs">
        <button class="chip on" data-action="req-tab" data-tab="min">Mínimos</button>
        <button class="chip" data-action="req-tab" data-tab="rec">Recomendados</button>
      </div>
      <div class="req-panel on" data-req="min">${reqRows(g.requirements.min)}</div>
      <div class="req-panel" data-req="rec">${reqRows(g.requirements.rec)}</div>
    </div>`;
  setView(rid, html);
}

async function cartView() {
  const rid = renderId;
  const games = await getGames();
  const items = S.cart.map((id) => games.find((g) => g.id === id)).filter(Boolean);
  if (items.length !== S.cart.length) { S.cart = items.map((g) => g.id); saveCart(); }
  if (!items.length) {
    setView(rid, `<h1 class="reveal">Carrinho</h1><div class="empty reveal" style="--i:1"><div class="big">${icon('cart', 34)}</div>Seu carrinho está vazio.<a class="btn sm" href="#/store">Ir para a loja</a></div>`);
    return;
  }
  const total = items.reduce((s, g) => s + g.price, 0);
  setView(rid, `
    <h1 class="reveal" style="margin-bottom:20px">Carrinho</h1>
    ${items.map((g, i) => `<div class="row reveal" style="--i:${i + 1}">
      <div class="thumb">${art(g, 'thumb')}</div>
      <div class="grow"><div class="rtitle" data-action="open" data-id="${esc(g.id)}">${esc(g.title)}</div><div class="muted">${esc(g.developer)}</div></div>
      <div class="card-price" style="margin:0">${priceHTML(g)}</div>
      <button class="btn ghost sm" data-action="remove-cart" data-id="${esc(g.id)}">Remover</button>
    </div>`).join('')}
    <div class="total reveal" style="--i:${items.length + 1}"><span>Total: <b>${brl(total)}</b></span><button class="btn lg" data-action="buy">Finalizar compra (simulada)</button></div>
    <p class="note-line">Compra de demonstração: nenhum pagamento real é feito.</p>`);
}

async function friendsView() {
  const rid = renderId;
  const [friends] = await Promise.all([api('/api/friends'), getGames()]);
  const paint = () => {
    const q = (document.getElementById('fsearch') || { value: '' }).value.trim().toLowerCase();
    const list = friends.filter((f) => f.name.toLowerCase().includes(q));
    const on = list.filter((f) => f.status !== 'offline');
    const off = list.filter((f) => f.status === 'offline');
    document.getElementById('flist').innerHTML =
      `<h2 style="margin:6px 0 12px">Online (${on.length})</h2>${on.map(friendRow).join('') || '<p class="muted">Ninguém online.</p>'}
       <h2 style="margin:26px 0 12px">Offline (${off.length})</h2>${off.map(friendRow).join('') || '<p class="muted">Ninguém offline.</p>'}`;
  };
  const html = `<div class="page-head reveal" style="--i:0"><h1>Amigos</h1></div>
    <p class="muted reveal" style="--i:1;margin:-8px 0 16px">Amigos de exemplo (fictícios).</p>
    <label class="search reveal" style="--i:1;max-width:420px;margin-bottom:20px">${icon('search', 18)}<input id="fsearch" type="search" placeholder="Buscar amigos..." autocomplete="off"></label>
    <div id="flist"></div>`;
  if (!setView(rid, html)) return;
  document.getElementById('fsearch').addEventListener('input', paint);
  paint();
}

async function communityView() {
  const rid = renderId;
  const [posts] = await Promise.all([api('/api/community'), getGames()]);
  const html = `<div class="page-head reveal" style="--i:0"><h1>Comunidade</h1></div>
    <p class="muted reveal" style="--i:1;margin:-8px 0 16px">Posts de exemplo (fictícios).</p>
    ${posts.map((p, i) => {
      const g = gamesById.get(p.game);
      const liked = S.liked.has(p.id);
      return `<article class="post reveal" style="--i:${i + 1}">
        <div class="post-head">${avatar(p.author, '', 'lg')}<div><b>${esc(p.author)}</b><div class="muted" style="font-size:13px">${esc(p.time)}${g ? ' · em <a href="#/game/' + enc(g.id) + '" style="color:#c4b5fd">' + esc(g.title) + '</a>' : ''}</div></div></div>
        <p>${esc(p.text)}</p>
        <button class="like ${liked ? 'on' : ''}" data-action="like" data-id="${esc(p.id)}" data-base="${p.likes}">${icon('heart', 16)}<span>${p.likes + (liked ? 1 : 0)}</span></button>
      </article>`;
    }).join('')}`;
  setView(rid, html);
}

function dlInfo(d) {
  const left = Math.max(0, (d.size * 1024 * (1 - d.pct / 100)) / d.speed);
  return `${d.speed.toFixed(0)} MB/s · ${left < 60 ? Math.ceil(left) + ' s' : Math.ceil(left / 60) + ' min'} restantes`;
}

function downloadsViewHTML() {
  const active = [...downloads.entries()];
  const live = active.length
    ? active.map(([id, d], i) => `<div class="row reveal" style="--i:${i + 1}">
        <div class="thumb">${art(gamesById.get(id) || { colors: ['#333', '#111'], emoji: '🎮', title: '' }, 'thumb')}</div>
        <div class="grow"><div class="rtitle" data-action="open" data-id="${esc(id)}">${esc(d.title)}</div>
          <div class="dl-wrap" style="margin-top:6px"><span class="bar"><i data-dl-bar="${esc(id)}" style="width:${d.pct}%"></i></span>
          <small><span data-dl-pct="${esc(id)}">${Math.round(d.pct)}%</span><span data-dl-info="${esc(id)}">${esc(dlInfo(d))}</span></small></div></div>
      </div>`).join('')
    : `<div class="empty"><div class="big">${icon('download', 34)}</div>Nenhum download em andamento.<a class="btn sm" href="#/library">Ir para a biblioteca</a></div>`;
  const done = S.history.length
    ? S.history.map((h) => `<div class="row"><div class="grow"><b>${esc(h.title)}</b><div class="muted">${esc(h.size)} GB · concluído às ${esc(h.at)}</div></div><span class="tag">Instalado</span></div>`).join('')
    : '<p class="muted">Nada concluído nesta sessão.</p>';
  return `<div class="page-head reveal" style="--i:0"><h1>Downloads</h1></div>
    <h2 style="margin-bottom:12px">Em andamento</h2>${live}
    <h2 style="margin:28px 0 12px">Concluídos</h2>${done}`;
}
async function downloadsView() {
  const rid = renderId;
  await getGames();
  setView(rid, downloadsViewHTML());
}

function publishView(errorMsg) {
  const rid = renderId;
  setView(rid, `
    <h1 class="reveal">Publicar jogo</h1>
    <p class="muted reveal" style="--i:1;margin:6px 0 20px">Portal do desenvolvedor (protótipo). Numa loja real, aqui entram o envio do jogo, a verificação de segurança e o contrato.</p>
    ${errorMsg ? `<p class="error">${esc(errorMsg)}</p>` : ''}
    <form id="publish-form" class="reveal" style="--i:2">
      <label class="f">Título<input type="text" name="title" maxlength="60" required></label>
      <label class="f">Desenvolvedor / estúdio<input type="text" name="developer" maxlength="60" required></label>
      <label class="f">Frase de destaque (opcional)<input type="text" name="tagline" maxlength="100"></label>
      <label class="f">Descrição<textarea name="description" maxlength="1000" required></textarea></label>
      <label class="f">Gêneros (separados por vírgula)<input type="text" name="genres" placeholder="Ação, Aventura" required></label>
      <div class="two">
        <label class="f">Preço (R$, use 0 para grátis)<input type="number" name="price" min="0" max="1000" step="0.01" value="0" required></label>
        <label class="f">Tamanho (GB)<input type="number" name="sizeGB" min="0.1" max="200" step="0.1" value="1" required></label>
      </div>
      <div><button class="btn lg" type="submit">Publicar na loja</button></div>
    </form>`);
  document.getElementById('publish-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const body = Object.fromEntries(new FormData(ev.target).entries());
    try {
      const game = await api('/api/games', { method: 'POST', body });
      toast('Jogo publicado na loja.');
      notify(`"${game.title}" foi publicado.`);
      location.hash = '#/game/' + enc(game.id);
    } catch (err) {
      publishView(err.message);
    }
  });
}

async function settingsView() {
  const rid = renderId;
  const html = `<h1 class="reveal">Configurações</h1>
    <div class="panel reveal" style="--i:1;margin-top:18px;max-width:620px">
      <h3>Perfil</h3>
      <form id="profile-form" style="max-width:none">
        <label class="f">Nome de exibição<input type="text" name="name" maxlength="24" value="${esc(S.profile.name)}" required></label>
        <div><button class="btn" type="submit">Salvar</button></div>
      </form>
    </div>
    <div class="panel reveal" style="--i:2;margin-top:18px;max-width:620px">
      <h3>Aparência</h3>
      <label class="switch"><span><b>Reduzir animações</b><div class="muted" style="font-size:13px">Desliga movimentos e transições da interface.</div></span>
        <input type="checkbox" id="reduce" ${S.profile.reduceMotion ? 'checked' : ''}><span class="track"></span></label>
    </div>
    <div class="panel reveal" style="--i:3;margin-top:18px;max-width:620px">
      <h3>Sobre</h3>
      <p class="muted">Life · protótipo v0.2. Os jogos, amigos e posts são fictícios, o pagamento é simulado e nenhum arquivo de jogo é baixado de verdade.</p>
    </div>`;
  if (!setView(rid, html)) return;
  document.getElementById('profile-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const name = new FormData(ev.target).get('name');
    try {
      S.profile = await api('/api/profile', { method: 'PUT', body: { name } });
      applyProfile();
      toast('Perfil salvo.');
    } catch (err) { toast(err.message); }
  });
  document.getElementById('reduce').addEventListener('change', async (ev) => {
    try {
      S.profile = await api('/api/profile', { method: 'PUT', body: { reduceMotion: ev.target.checked } });
      applyProfile();
    } catch (err) { toast(err.message); }
  });
}

/* ============================== downloads ============================== */
function renderMini() {
  const el = document.getElementById('mini-dl');
  if (!el) return;
  if (!downloads.size) { el.classList.remove('on'); el.innerHTML = ''; return; }
  const [id, d] = downloads.entries().next().value;
  el.classList.add('on');
  el.innerHTML = `<a href="#/downloads" class="mini-card"><span class="mini-t">${icon('download', 16)} ${esc(d.title)}</span><span class="bar"><i data-dl-bar="${esc(id)}" style="width:${d.pct}%"></i></span><span class="mini-s" data-dl-pct="${esc(id)}">${Math.round(d.pct)}%</span></a>`;
}

function paintDownloads() {
  downloads.forEach((d, id) => {
    document.querySelectorAll(`[data-dl-bar="${id}"]`).forEach((b) => { b.style.width = d.pct + '%'; });
    document.querySelectorAll(`[data-dl-pct="${id}"]`).forEach((b) => { b.textContent = Math.round(d.pct) + '%'; });
    document.querySelectorAll(`[data-dl-info="${id}"]`).forEach((b) => { b.textContent = dlInfo(d); });
  });
}

function startDownload(id) {
  if (downloads.has(id)) return;
  const g = gamesById.get(id);
  const size = g ? g.sizeGB : 5;
  const dur = Math.min(12, Math.max(4, 3 + size / 6)); // segundos
  const d = { pct: 0, title: g ? g.title : id, size, speed: 40 + Math.random() * 50, dur };
  downloads.set(id, d);
  renderMini();
  refreshView();
  const timer = setInterval(async () => {
    d.pct = Math.min(100, d.pct + (100 / (dur * 4)) * (0.8 + Math.random() * 0.4));
    d.speed = Math.max(20, d.speed + (Math.random() - 0.5) * 8);
    paintDownloads();
    if (d.pct < 100) return;
    clearInterval(timer);
    try { await api('/api/library/' + enc(id) + '/install', { method: 'POST' }); }
    catch (err) { toast(err.message); }
    downloads.delete(id);
    S.history.unshift({ title: d.title, size: String(d.size), at: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) });
    notify(`${d.title} foi instalado.`);
    toast(`${d.title} instalado.`);
    renderMini();
    refreshView();
  }, 250);
}

/* =============================== roteador =============================== */
const ROUTES = {
  '': homeView, store: storeView, library: libraryView, friends: friendsView, community: communityView,
  downloads: downloadsView, cart: cartView, publish: () => publishView(), settings: settingsView, game: gameView,
};

async function render({ animate = true } = {}) {
  const parts = location.hash.replace(/^#/, '').split('/'); // "/game/abc" -> ["", "game", "abc"]
  const name = parts[1] || '';
  const arg = parts[2] ? decodeURIComponent(parts[2]) : '';
  current = { name, arg };
  renderId++;
  clearTimers();
  heroCtl = null;
  updateNav(name);
  updateBadge();
  $view.classList.toggle('view-enter', animate);
  try {
    await (ROUTES[name] || homeView)(arg);
    if (animate) $content.scrollTo({ top: 0, behavior: 'auto' });
  } catch (err) {
    $view.innerHTML = `<div class="empty error">${esc(err.message)}</div>`;
  }
}

// Atualiza a tela atual sem repetir a animação de entrada
function refreshView() {
  if (['library', 'downloads', 'game', 'cart'].includes(current.name)) return render({ animate: false });
}

window.addEventListener('hashchange', () => render());

/* ================================ ações ================================ */
function pop(el) {
  el.classList.remove('pop');
  void el.offsetWidth;
  el.classList.add('pop');
}

document.addEventListener('click', async (ev) => {
  // fecha o menu de notificações ao clicar fora
  const notesEl = document.getElementById('notes');
  if (!notesEl.hidden && !ev.target.closest('.notes-wrap')) notesEl.hidden = true;

  if (ev.target.closest('#bell')) {
    notesEl.hidden = !notesEl.hidden;
    if (!notesEl.hidden) {
      paintNotes();
      S.unread = 0;
      document.getElementById('bell-dot').hidden = true;
    }
    return;
  }

  const el = ev.target.closest('[data-action]');
  if (!el) return;
  const id = el.dataset.id;
  try {
    switch (el.dataset.action) {
      case 'open': location.hash = '#/game/' + enc(id); break;
      case 'back': ev.preventDefault(); if (history.length > 1) history.back(); else location.hash = '#/'; break;
      case 'genre': S.genre = el.dataset.genre; await loadGrid(); break;
      case 'hero': if (heroCtl) heroCtl.go(el.dataset.to); break;
      case 'lib-tab':
        S.libTab = el.dataset.tab;
        document.querySelectorAll('.tabs .tab').forEach((t) => t.classList.toggle('on', t.dataset.tab === S.libTab));
        placeTabIndicator();
        paintLibrary(libItems);
        break;
      case 'req-tab':
        document.querySelectorAll('[data-action="req-tab"]').forEach((t) => t.classList.toggle('on', t === el));
        document.querySelectorAll('.req-panel').forEach((p) => p.classList.toggle('on', p.dataset.req === el.dataset.tab));
        break;
      case 'add-cart':
        if (!S.cart.includes(id)) S.cart.push(id);
        saveCart();
        toast('Adicionado ao carrinho.');
        await render({ animate: false });
        break;
      case 'buy-now':
        if (!S.cart.includes(id)) S.cart.push(id);
        saveCart();
        location.hash = '#/cart';
        break;
      case 'remove-cart':
        S.cart = S.cart.filter((x) => x !== id);
        saveCart();
        await render({ animate: false });
        break;
      case 'buy': {
        const result = await api('/api/purchase', { method: 'POST', body: { ids: S.cart } });
        S.cart = [];
        saveCart();
        toast(`Compra simulada concluída (${brl(result.total)}).`);
        notify(`Compra de ${result.purchased.length} jogo(s) concluída.`);
        location.hash = '#/library';
        break;
      }
      case 'install': startDownload(id); break;
      case 'uninstall':
        await api('/api/library/' + enc(id) + '/install', { method: 'DELETE' });
        toast('Jogo desinstalado.');
        await render({ animate: false });
        break;
      case 'play': {
        const r = await api('/api/library/' + enc(id) + '/play', { method: 'POST' });
        toast(`Sessão simulada: +${r.minutes} min de jogo.`);
        if (r.newAchievements > 0) {
          const g = gamesById.get(id);
          notify(`Nova conquista em ${g ? g.title : 'um jogo'}! 🏆`);
          toast(`Nova conquista desbloqueada! 🏆 (+${r.newAchievements})`);
        }
        await render({ animate: false });
        break;
      }
      case 'fav': {
        const on = !S.favorites.has(id);
        await api('/api/favorites/' + enc(id), { method: on ? 'POST' : 'DELETE' });
        if (on) S.favorites.add(id); else S.favorites.delete(id);
        document.querySelectorAll(`[data-action="fav"][data-id="${id}"]`).forEach((b) => { b.classList.toggle('on', on); pop(b); });
        toast(on ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.');
        if (current.name === 'library' && S.libTab === 'favorites') await render({ animate: false });
        break;
      }
      case 'like': {
        const base = Number(el.dataset.base);
        const on = !S.liked.has(id);
        if (on) S.liked.add(id); else S.liked.delete(id);
        el.classList.toggle('on', on);
        el.querySelector('span').textContent = base + (on ? 1 : 0);
        pop(el);
        break;
      }
    }
  } catch (err) {
    toast(err.message);
  }
});

// Efeito de ondas nos botões
document.addEventListener('pointerdown', (e) => {
  const b = e.target.closest('.btn');
  if (!b || b.disabled || S.profile.reduceMotion) return;
  const r = b.getBoundingClientRect();
  const d = Math.max(r.width, r.height) * 2;
  const s = document.createElement('span');
  s.className = 'ripple';
  s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  b.appendChild(s);
  setTimeout(() => s.remove(), 700);
});

// Inclinação 3D suave nos cartões
$view.addEventListener('mousemove', (e) => {
  const c = e.target.closest('.card');
  if (!c || S.profile.reduceMotion) return;
  const r = c.getBoundingClientRect();
  const x = (e.clientX - r.left) / r.width - 0.5;
  const y = (e.clientY - r.top) / r.height - 0.5;
  c.style.setProperty('--ry', (x * 8).toFixed(2) + 'deg');
  c.style.setProperty('--rx', (-y * 8).toFixed(2) + 'deg');
});
$view.addEventListener('mouseout', (e) => {
  const c = e.target.closest('.card');
  if (c && !c.contains(e.relatedTarget)) {
    c.style.setProperty('--rx', '0deg');
    c.style.setProperty('--ry', '0deg');
  }
});

// Busca global na barra do topo
document.getElementById('gsearch').addEventListener('input', (e) => {
  S.q = e.target.value;
  if (current.name === 'store') loadGrid();
  else location.hash = '#/store';
});

window.addEventListener('resize', () => { updateNav(current.name); placeTabIndicator(); });

/* ================================ início ================================ */
(async function boot() {
  buildChrome();
  try { S.profile = await api('/api/profile'); } catch (e) { /* usa o padrão */ }
  try { S.favorites = new Set(await api('/api/favorites')); } catch (e) { /* usa o padrão */ }
  applyProfile();
  updateBadge();
  await render();
})();
