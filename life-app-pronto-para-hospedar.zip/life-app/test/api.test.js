// Teste da API da loja. Rode com: npm test
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createServer } = require('../server');

const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'life-test-'));

// Simula dados antigos (versão 0.1): catálogo velho e estado sem os campos novos
fs.writeFileSync(path.join(dataDir, 'games.json'), JSON.stringify([
  { id: 'torre-de-sal', title: 'Torre de Sal VELHO', developer: 'x', price: 1, genres: ['Puzzle'], description: 'd', rating: 1, sizeGB: 1, releaseDate: '2024-01-01', emoji: '🧂', colors: ['#000', '#111'] },
  { id: 'meu-antigo', title: 'Meu Jogo Antigo', developer: 'Eu', price: 5, genres: ['Ação'], description: 'publicado antes', rating: 0, sizeGB: 2, releaseDate: '2025-01-01', emoji: '🎮', colors: ['#000', '#111'] },
]));
fs.writeFileSync(path.join(dataDir, 'state.json'), JSON.stringify({ library: [{ id: 'meu-antigo', purchasedAt: '2025-01-02', installed: true }] }));

const server = createServer({ dataDir });

async function main() {
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, url, body) => {
    const res = await fetch(base + url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) { /* não é JSON */ }
    return { status: res.status, json, text };
  };

  // ---- migração de dados antigos ----
  let r = await call('GET', '/api/games');
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.json.length, 13, '12 do catálogo + 1 publicado antes');
  assert.strictEqual(r.json.find((g) => g.id === 'torre-de-sal').title, 'Torre de Sal', 'seed substitui versão velha');
  const antigo = r.json.find((g) => g.id === 'meu-antigo');
  assert.ok(antigo, 'jogo publicado pelo usuário foi preservado');
  assert.ok(antigo.requirements.min.cpu && antigo.achievementsTotal === 20, 'jogo antigo ganhou campos novos');
  r = await call('GET', '/api/library');
  assert.strictEqual(r.json.length, 1);
  assert.strictEqual(r.json[0].installed, true, 'estado antigo preservado');
  assert.strictEqual(r.json[0].playMinutes, 0);

  // ---- catálogo ----
  const sn = (await call('GET', '/api/games/sertao-neon')).json;
  assert.strictEqual(sn.discount, 20, 'desconto calculado (79,90 de 99,90)');
  assert.strictEqual(sn.requirements.rec.ram, '32 GB');

  r = await call('GET', '/api/games?q=farol');
  assert.deepStrictEqual(r.json.map((g) => g.id), ['ultimo-farol']);
  r = await call('GET', '/api/games?genre=terror');
  assert.deepStrictEqual(r.json.map((g) => g.id).sort(), ['neblina-vermelha', 'ultimo-farol']);
  r = await call('GET', '/api/games?sort=price-asc');
  assert.strictEqual(r.json[0].price, 0);
  r = await call('GET', '/api/games?sort=discount');
  assert.ok(r.json[0].discount >= r.json[1].discount);
  assert.ok((await call('GET', '/api/genres')).json.includes('Competitivo'));
  assert.strictEqual((await call('GET', '/api/games/nao-existe')).status, 404);

  // ---- amigos e comunidade ----
  r = await call('GET', '/api/friends');
  assert.strictEqual(r.json.length, 10);
  r = await call('GET', '/api/games/sertao-neon/friends');
  assert.deepStrictEqual(r.json.map((f) => f.id).sort(), ['bia', 'gabi']);
  assert.strictEqual((await call('GET', '/api/games/xyz/friends')).status, 404);
  assert.strictEqual((await call('GET', '/api/community')).json.length, 6);

  // ---- publicar ----
  r = await call('POST', '/api/games', { title: '', developer: 'x', description: 'x', genres: 'a', price: 1, sizeGB: 1 });
  assert.strictEqual(r.status, 400);
  r = await call('POST', '/api/games', { title: 'Jogo X', developer: 'Dev', description: 'd', genres: 'Ação', price: -5, sizeGB: 1 });
  assert.strictEqual(r.status, 400, 'preço negativo rejeitado');
  r = await call('POST', '/api/games', { title: 'Meu Jogo Ótimo', developer: 'Dev', description: 'desc', genres: 'Ação, Aventura', price: 10, sizeGB: 2, tagline: 'oi' });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.json.id, 'meu-jogo-otimo');
  assert.ok(r.json.requirements && r.json.discount === 0);
  r = await call('POST', '/api/games', { title: 'Meu Jogo Ótimo', developer: 'Dev', description: 'desc', genres: 'Ação', price: 10, sizeGB: 2 });
  assert.strictEqual(r.json.id, 'meu-jogo-otimo-2', 'ids duplicados ganham sufixo');

  // ---- compra ----
  assert.strictEqual((await call('POST', '/api/purchase', { ids: [] })).status, 400);
  assert.strictEqual((await call('POST', '/api/purchase', { ids: ['nao-existe'] })).status, 400);
  assert.strictEqual((await call('POST', '/api/purchase', { ids: ['meu-antigo'] })).status, 400, 'já possui');
  r = await call('POST', '/api/purchase', { ids: ['torre-de-sal', 'rio-acima', 'torre-de-sal'] });
  assert.strictEqual(r.status, 201);
  assert.strictEqual(r.json.total, 19.9);
  assert.strictEqual(r.json.purchased.length, 2, 'duplicados no carrinho são ignorados');
  assert.strictEqual((await call('POST', '/api/purchase', { ids: ['torre-de-sal'] })).status, 400);

  // ---- instalar / jogar / desinstalar ----
  assert.strictEqual((await call('POST', '/api/library/torre-de-sal/play')).status, 400, 'precisa instalar antes');
  r = await call('POST', '/api/library/torre-de-sal/install');
  assert.strictEqual(r.json.installed, true);
  r = await call('POST', '/api/library/torre-de-sal/play');
  assert.strictEqual(r.status, 200);
  assert.ok(r.json.minutes >= 15 && r.json.minutes <= 90);
  assert.ok(r.json.entry.achievementsUnlocked <= 20, 'conquistas respeitam o total');
  r = await call('GET', '/api/library');
  const torre = r.json.find((e) => e.id === 'torre-de-sal');
  assert.ok(torre.playMinutes >= 15 && torre.game.title === 'Torre de Sal');
  assert.strictEqual((await call('DELETE', '/api/library/torre-de-sal/install')).json.installed, false);
  assert.strictEqual((await call('POST', '/api/library/sertao-neon/install')).status, 404, 'não instala o que não possui');
  assert.strictEqual((await call('POST', '/api/library/sertao-neon/play')).status, 404);

  // ---- favoritos ----
  assert.deepStrictEqual((await call('GET', '/api/favorites')).json, []);
  assert.deepStrictEqual((await call('POST', '/api/favorites/sertao-neon')).json, ['sertao-neon']);
  assert.deepStrictEqual((await call('POST', '/api/favorites/sertao-neon')).json, ['sertao-neon'], 'não duplica');
  assert.strictEqual((await call('POST', '/api/favorites/nao-existe')).status, 404);
  await call('POST', '/api/favorites/torre-de-sal');
  r = await call('GET', '/api/library');
  assert.strictEqual(r.json.find((e) => e.id === 'torre-de-sal').favorite, true);
  assert.deepStrictEqual((await call('DELETE', '/api/favorites/sertao-neon')).json, ['torre-de-sal']);

  // ---- perfil ----
  assert.deepStrictEqual((await call('GET', '/api/profile')).json, { name: 'Jogador', reduceMotion: false });
  r = await call('PUT', '/api/profile', { name: '  Maria  ', reduceMotion: true });
  assert.deepStrictEqual(r.json, { name: 'Maria', reduceMotion: true });
  assert.strictEqual((await call('PUT', '/api/profile', { name: '' })).status, 400);
  assert.strictEqual((await call('PUT', '/api/profile', { name: 'x'.repeat(30) })).status, 400);
  assert.strictEqual((await call('GET', '/api/profile')).json.name, 'Maria', 'perfil não mudou após erro');

  // ---- arquivos estáticos e segurança ----
  r = await call('GET', '/');
  assert.strictEqual(r.status, 200);
  assert.ok(r.text.includes('<title>Life</title>'));
  assert.strictEqual((await call('GET', '/app.js')).status, 200);
  assert.strictEqual((await call('GET', '/styles.css')).status, 200);
  for (const p of ['/..%2Fserver.js', '/%2e%2e/package.json', '/..%2f..%2fetc%2fpasswd']) {
    r = await call('GET', p);
    assert.ok(r.status === 403 || r.status === 404, `path traversal bloqueado (${p}), veio ${r.status}`);
  }
  assert.strictEqual((await call('POST', '/qualquer-coisa', {})).status, 405);
  const bad = await fetch(base + '/api/purchase', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{quebrado' });
  assert.strictEqual(bad.status, 400);

  console.log('API OK: todos os testes passaram');
}

const cleanup = () => { server.close(); fs.rmSync(dataDir, { recursive: true, force: true }); };
main().then(cleanup).catch((err) => { console.error('FALHOU:', err.stack || err.message); cleanup(); process.exit(1); });
